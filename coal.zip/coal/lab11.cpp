#include <iostream>
using namespace std;
int main()
{
	int number = 0x87654321;
	int temp = 0;
	_asm
	{
			mov eax, [number]//store number in register

			mov ebx, eax
			and ebx, 0x000000ff //add statement
			ror ebx, 8 // rotate right statement

			mov ecx, eax
			and ecx, 0xff000000 //add statement
			rol ecx, 8 //rotate left statement
			or ebx, ecx //or statement

			add [temp], ebx

			and ebx, 0x00f00000 //add statement
			shr ebx, 4 //shift right statement

			and ecx, 0x000f0000 //add statement
			shl ecx,4 //shift left statement

			or ebx,ecx //or statement
			or ebx, [temp] //or statement

			mov edx, [temp]
			mov [number],edx //store number from register
	}

	cout << "number after process : "<<number << endl; //print statement

	system("pause");
	return 0;
}